# Overlay Pro TT — Landing (sources)

Stack: Vite + React + TypeScript + Tailwind + Framer Motion + lucide-react

## Dev
```bash
npm install
npm run dev
```

## Build
```bash
npm run build
npm run preview
```

- Menu mobile burger inclus
- Smooth scroll sur toutes les ancres (y compris GitHub)
- URL script Tampermonkey (prod): https://cdn.jsdelivr.net/gh/CreepsoOff/Wplace-Overlay-Pro@development/dist/overlay-pro-tt.user.js
