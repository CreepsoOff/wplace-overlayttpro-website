import { useEffect, useMemo, useState } from "react";
import { motion } from "framer-motion";
import {
  ArrowRight,
  CheckCircle2,
  Download,
  Github,
  Palette,
  Layers,
  Share2,
  Zap,
  Grid3X3,
  MonitorSmartphone,
  ChevronDown,
  SlidersHorizontal,
  MousePointer2,
  PlayCircle,
} from "lucide-react";

/*************************
 * Utilities & Helpers
 *************************/

// Typewriter (letter-by-letter) using Framer Motion staggered children
function Typewriter({
  text,
  speed = 22,
  className = "",
  as: Tag = "div",
  cursor = false,
  dataTestId,
}: {
  text: string;
  speed?: number;
  className?: string;
  as?: any;
  cursor?: boolean;
  dataTestId?: string;
}) {
  const chars = useMemo(() => text.split("").map((c, i) => ({ c, i })), [text]);
  const container = {
    hidden: { opacity: 0 },
    show: (custom: number) => ({
      opacity: 1,
      transition: { staggerChildren: speed / 1000, delayChildren: custom || 0 },
    }),
  };
  const child = { hidden: { opacity: 0, y: 8 }, show: { opacity: 1, y: 0 } };
  return (
    <motion.div variants={container} initial="hidden" animate="show" custom={0.2} className={className}>
      <Tag className="inline" data-testid={dataTestId}>
        {chars.map(({ c, i }) => (
          <motion.span key={i} variants={child} className="inline-block will-change-transform">
            {c === " " ? "\u00A0" : c}
          </motion.span>
        ))}
        {cursor && (
          <span
            data-testid="tw-cursor"
            className="ml-1 inline-block h-[1em] w-[2px] animate-pulse bg-white/80 align-[-0.15em]"
          />
        )}
      </Tag>
    </motion.div>
  );
}

// Smooth scroll helper (accounts for sticky header)
function scrollToSection(id: string) {
  const el = document.querySelector(id) as HTMLElement | null;
  if (!el) return;
  const header = document.querySelector("header");
  const headerH = header ? (header as HTMLElement).offsetHeight : 0;
  const top = window.scrollY + el.getBoundingClientRect().top - (headerH + 12);
  window.scrollTo({ top, behavior: "smooth" });
}

// Simple page loader overlay
function PageLoader({ done }: { done: boolean }) {
  return (
    <motion.div
      initial={{ opacity: 1 }}
      animate={{ opacity: done ? 0 : 1 }}
      transition={{ duration: 0.6, ease: "easeOut", delay: done ? 0.05 : 0 }}
      style={{ pointerEvents: done ? "none" : "auto" }}
      className="fixed inset-0 z-[60] grid place-items-center bg-[#0B0B10]"
    >
      <motion.div
        initial={{ scale: 0.96, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.6, ease: "easeOut" }}
        className="flex flex-col items-center gap-3"
      >
        <div className="grid h-14 w-14 place-items-center rounded-2xl bg-gradient-to-tr from-fuchsia-500 to-violet-500 shadow-lg">
          <Layers className="h-7 w-7 text-white" />
        </div>
        <Typewriter as="p" className="text-sm text-white/70" text="Loading Overlay Pro TT…" speed={18} />
      </motion.div>
    </motion.div>
  );
}

/*************************
 * UI Primitives
 *************************/
function Button({ className = "", children, ...props }: any) {
  return (
    <button
      className={`inline-flex items-center gap-2 rounded-2xl px-5 py-3 text-sm font-medium shadow-sm hover:shadow transition-all active:scale-[0.98] ${className}`}
      {...props}
    >
      {children}
    </button>
  );
}

function Badge({ children, className = "" }: any) {
  return (
    <span className={`rounded-full border border-white/15 bg-white/5 px-3 py-1 text-xs font-medium text-white/80 backdrop-blur ${className}`}>{children}</span>
  );
}

function Container({ children, className = "" }: any) {
  return <div className={`mx-auto w-full max-w-6xl px-4 sm:px-6 lg:px-8 ${className}`}>{children}</div>;
}

/*************************
 * Decorative Background
 *************************/
function Aurora() {
  return (
    <div aria-hidden className="pointer-events-none absolute inset-0 overflow-hidden">
      <div className="absolute -top-24 -left-24 h-[36rem] w-[36rem] rounded-full bg-gradient-to-tr from-fuchsia-500/20 via-violet-500/20 to-sky-500/20 blur-3xl" />
      <div className="absolute bottom-[-10rem] right-[-10rem] h-[32rem] w-[32rem] rounded-full bg-gradient-to-tr from-amber-400/20 via-pink-500/20 to-purple-500/20 blur-3xl" />
      <div className="absolute left-1/2 top-1/2 h-[24rem] w-[24rem] -translate-x-1/2 -translate-y-1/2 rounded-full bg-gradient-to-tr from-blue-500/10 to-emerald-400/10 blur-3xl" />
      <div className="absolute inset-0 bg-[radial-gradient(70%_50%_at_50%_0%,rgba(255,255,255,0.06),transparent)]" />
    </div>
  );
}

/*************************
 * Feature Card
 *************************/
function Feature({ icon: Icon, title, desc }: { icon: any; title: string; desc: string }) {
  return (
    <motion.div
      initial={{ y: 20, opacity: 0 }}
      whileInView={{ y: 0, opacity: 1 }}
      viewport={{ once: true }}
      transition={{ duration: 0.6, ease: "easeOut" }}
      className="group relative rounded-3xl border border-white/10 bg-white/5 p-5 backdrop-blur-sm shadow-[0_0_0_1px_rgba(255,255,255,0.02)] hover:shadow-lg hover:shadow-violet-500/10"
    >
      <div className="absolute inset-0 rounded-3xl bg-gradient-to-tr from-white/0 to-white/5 opacity-0 transition-opacity group-hover:opacity-100" />
      <div className="flex items-start gap-4">
        <div className="rounded-2xl bg-white/10 p-3 text-white/90">
          <Icon className="h-6 w-6" />
        </div>
        <div>
          <h3 className="text-base font-semibold tracking-tight text-white">{title}</h3>
          <p className="mt-1 text-sm leading-relaxed text-white/70">{desc}</p>
        </div>
      </div>
    </motion.div>
  );
}

/*************************
 * Demo Video Placeholder
 *************************/
function VideoMock() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.7 }}
      className="relative aspect-[16/9] w-full overflow-hidden rounded-3xl border border-white/10 bg-black p-[1px] bg-gradient-to-tr from-fuchsia-500/10 via-violet-500/10 to-sky-500/10"
    >
      <div className="absolute inset-0 grid place-items-center">
        <div className="flex flex-col items-center gap-3 text-center">
          <PlayCircle className="h-12 w-12 opacity-80" />
          <p className="text-sm text-white/70">Drop a short demo .webm/.mp4 here</p>
          <p className="text-xs text-white/50">(or wire it to your real video later)</p>
        </div>
      </div>
      {/* Decorative scanlines */}
      <div className="pointer-events-none absolute inset-0 bg-[linear-gradient(transparent_0,rgba(255,255,255,0.02)_2px,transparent_3px)] bg-[length:100%_6px]" />
    </motion.div>
  );
}

/*************************
 * FAQ Item
 *************************/
function FAQItem({ q, a, open, onToggle }: { q: string; a: string; open: boolean; onToggle: () => void }) {
  const handleKey = (e: any) => {
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      onToggle();
    }
  };
  return (
    <div
      role="button"
      tabIndex={0}
      onClick={onToggle}
      onKeyDown={handleKey}
      className="group rounded-2xl p-[1px] bg-gradient-to-r from-fuchsia-500/12 via-violet-500/12 to-sky-500/12 cursor-pointer"
      aria-expanded={open}
    >
      <div className="rounded-2xl border border-white/10 bg-white/5 p-4">
        <div className="flex w-full items-center justify-between text-left">
          <span className="text-sm font-semibold text-white">
            {q}
          </span>
          <svg
            className={`h-4 w-4 transition-transform ${open ? 'rotate-180' : ''}`}
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <path d="M6 9l6 6 6-6" />
          </svg>
        </div>
        <div className={`grid transition-[grid-template-rows] duration-300 ease-in-out ${open ? 'grid-rows-[1fr]' : 'grid-rows-[0fr]'}`}>
          <div className="overflow-hidden">
            <motion.p initial={false} animate={{ opacity: open ? 1 : 0, y: open ? 0 : -4 }} transition={{ duration: 0.2 }} className="mt-3 text-sm text-white/70">
              {a}
            </motion.p>
          </div>
        </div>
      </div>
    </div>
  );
}

/*************************
 * Header (Glass, Smooth Scroll)
 *************************/
function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    onScroll();
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setMobileOpen(false);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  const closeAndScroll = (id: string) => {
    setMobileOpen(false);
    setTimeout(() => scrollToSection(id), 50);
  };

  return (
    <header className={`sticky top-0 z-50 transition-[background,backdrop-filter] ${scrolled ? "backdrop-blur supports-[backdrop-filter]:bg-black/40" : "bg-transparent"}`}>
      <Container className="relative flex h-16 items-center justify-between">
        {/* Left: logo */}
        <div className="flex items-center gap-2">
          <div className="grid h-8 w-8 place-items-center rounded-xl bg-gradient-to-tr from-fuchsia-500 to-violet-500 text-white shadow-md">
            <Layers className="h-4 w-4" />
          </div>
          <span className="text-sm font-semibold tracking-tight text-white">Overlay Pro TT</span>
        </div>

        {/* Center: mobile burger (visible < md) */}
        <div className="absolute left-1/2 -translate-x-1/2 md:hidden">
          <button
            aria-label={mobileOpen ? 'Fermer le menu' : 'Ouvrir le menu'}
            onClick={() => setMobileOpen((o) => !o)}
            className="group grid h-9 w-9 place-items-center rounded-full border border-white/15 bg-white/5 backdrop-blur hover:bg-white/10 active:scale-95"
          >
            {/* three stacked lines */}
            <div className={`space-y-1.5 transition-all ${mobileOpen ? 'opacity-60' : 'opacity-100'}`}>
              <span className="block h-[2px] w-5 rounded bg-white" />
              <span className="block h-[2px] w-5 rounded bg-white" />
              <span className="block h-[2px] w-5 rounded bg-white" />
            </div>
          </button>
        </div>

        {/* Right: CTA & desktop nav */}
        <nav className="hidden items-center gap-6 text-sm text-white/70 md:flex">
          <button onClick={() => scrollToSection('#features')} className="hover:text-white">Features</button>
          <button onClick={() => scrollToSection('#demo')} className="hover:text-white">Demo</button>
          <button onClick={() => scrollToSection('#install')} className="hover:text-white">Installation</button>
          <button onClick={() => scrollToSection('#faq')} className="hover:text-white">FAQ</button>
          <button onClick={() => scrollToSection('#github')} className="hover:text-white">GitHub</button>
        </nav>
        <div className="flex items-center gap-3">
          <button onClick={() => scrollToSection('#install')}>
            <Button className="bg-white text-black hover:bg-white/90">Installer le Userscript <ArrowRight className="h-4 w-4" /></Button>
          </button>
        </div>
      </Container>
      <div className="h-px w-full bg-gradient-to-r from-transparent via-white/10 to-transparent" />

      {/* Mobile menu overlay */}
      {mobileOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="md:hidden fixed inset-0 z-40"
        >
          {/* backdrop */}
          <div onClick={() => setMobileOpen(false)} className="absolute inset-0 bg-black/60 backdrop-blur-sm" />
          {/* sheet */}
          <motion.div
            initial={{ y: -16, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.2, ease: 'easeOut' }}
            className="absolute left-0 right-0 top-16 mx-4 rounded-2xl border border-white/10 bg-[#101018] p-3 shadow-lg"
          >
            <div className="grid gap-2">
              <button onClick={() => closeAndScroll('#features')} className="w-full rounded-xl px-4 py-3 text-left text-sm text-white/90 hover:bg-white/10">Features</button>
              <button onClick={() => closeAndScroll('#demo')} className="w-full rounded-xl px-4 py-3 text-left text-sm text-white/90 hover:bg-white/10">Demo</button>
              <button onClick={() => closeAndScroll('#install')} className="w-full rounded-xl px-4 py-3 text-left text-sm text-white/90 hover:bg-white/10">Installation</button>
              <button onClick={() => closeAndScroll('#faq')} className="w-full rounded-xl px-4 py-3 text-left text-sm text-white/90 hover:bg-white/10">FAQ</button>
              <button onClick={() => closeAndScroll('#github')} className="w-full rounded-xl px-4 py-3 text-left text-sm text-white/90 hover:bg-white/10">GitHub</button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </header>
  );
}

/*************************
 * Hero (Full-screen, Centered)
 *************************/
function Hero() {
  return (
    <section className="relative overflow-hidden">
      <Aurora />
      {/* Use viewport height minus header (h-16 => 4rem) so the bottom CTA is always visible without extra scroll */}
      <Container
        className="relative grid place-items-center py-20 md:py-28"
        style={{ minHeight: "calc(100svh - 4rem)" }}
      >
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7 }}
          className="relative z-10 mx-auto max-w-4xl text-center"
        >
          <div className="mb-6 flex items-center justify-center gap-2">
            <Badge>Wplace.live power tool</Badge>
            <Badge className="hidden sm:inline-flex">Open‑source</Badge>
          </div>

          <Typewriter
            as="h1"
            className="mx-auto max-w-4xl text-5xl font-black tracking-tight text-transparent sm:text-6xl lg:text-7xl bg-gradient-to-tr from-fuchsia-400 via-violet-400 to-sky-400 bg-clip-text drop-shadow-[0_0_20px_rgba(139,92,246,0.25)]"
            text="Overlay Pro TT"
            speed={14}
          />

          <Typewriter
            as="h2"
            className="mt-4 text-2xl font-semibold text-white/90 sm:text-3xl"
            text="Pixel‑perfect overlays for wplace.live"
            speed={12}
            cursor={true}
          />
          <Typewriter
            as="p"
            className="mx-auto mt-4 max-w-2xl text-base leading-relaxed text-white/70"
            text="Transform your wplace.live experience with the most advanced overlay system. Intelligent color matching, dual display modes, real‑time updates, and precise controls."
            speed={8}
          />

          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.55 }}
            className="mt-10 flex flex-col items-center justify-center gap-3 sm:flex-row sm:gap-4"
          >
            <button onClick={() => scrollToSection('#install')}>
              <Button className="bg-white text-black hover:bg-white/90">Installer le Userscript <Download className="h-4 w-4" /></Button>
            </button>
            <button onClick={() => scrollToSection('#demo')}>
              <Button className="border border-white/20 bg-white/0 text-white hover:bg-white/10">Voir la démo <PlayCircle className="h-4 w-4" /></Button>
            </button>
          </motion.div>
        </motion.div>

        {/* Decorative floating rings */}
        <motion.div
          aria-hidden
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 0.5, scale: 1 }}
          transition={{ duration: 1.2, ease: 'easeOut' }}
          className="pointer-events-none absolute -left-20 top-24 h-64 w-64 rounded-full bg-gradient-to-tr from-fuchsia-500/15 to-violet-500/15 blur-2xl"
        />
        <motion.div
          aria-hidden
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 0.5, scale: 1 }}
          transition={{ duration: 1.2, delay: 0.15, ease: 'easeOut' }}
          className="pointer-events-none absolute -right-24 bottom-16 h-72 w-72 rounded-full bg-gradient-to-tr from-sky-500/15 to-emerald-400/15 blur-2xl"
        />
      </Container>
      {/* Scroll indicator anchored to the section, not the inner content, so it never overlaps mid‑screen */}
      <motion.button
        onClick={() => scrollToSection('#features')}
        aria-label="Scroll to features"
        initial={{ opacity: 0, y: -6 }}
        animate={{ opacity: 0.9, y: 0 }}
        transition={{ delay: 0.9, duration: 0.6 }}
        className="pointer-events-auto absolute bottom-6 left-1/2 z-10 -translate-x-1/2 rounded-full border border-white/15 bg-white/5 p-3 text-white/80 backdrop-blur hover:bg-white/10"
      >
        <ChevronDown className="h-5 w-5 animate-bounce" />
      </motion.button>
    </section>
  );
}

/*************************
 * Features Grid
 *************************/
function Features() {
  const features = [
    { icon: Layers, title: "Multiple overlays", desc: "Run several overlays simultaneously for complex projects." },
    { icon: Share2, title: "Direct sharing", desc: "Share overlays instantly with friends and collaborators." },
    { icon: Palette, title: "Smart color matching", desc: "Intelligent matching to the wplace palette with tolerance control." },
    { icon: Grid3X3, title: "Dual display modes", desc: "Switch between full overlay and precise dot mode." },
    { icon: Zap, title: "Real‑time processing", desc: "Instant overlay updates with zero lag, even on large images." },
    { icon: MonitorSmartphone, title: "Universal compatibility", desc: "Works across all modern browsers and setups." },
    { icon: SlidersHorizontal, title: "Transparency controls", desc: "Overlay above or behind tiles with pixel‑perfect precision." },
    { icon: MousePointer2, title: "Flexible positioning", desc: "Drag, resize, and snap‑to‑grid with intuitive controls." },
  ];

  return (
    <section id="features" className="relative scroll-mt-24 py-16 sm:py-20">
      <Container>
        <div className="mx-auto mb-10 max-w-2xl text-center">
          <Typewriter as="h2" className="bg-gradient-to-tr from-fuchsia-400 via-violet-400 to-sky-400 bg-clip-text text-3xl font-extrabold tracking-tight text-transparent sm:text-4xl" text="Powerful features for wplace.live" speed={10} />
          <p className="mt-3 text-white/70">Everything you need for pixel‑perfect overlays, nothing you don't.</p>
        </div>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {features.map((f) => (
            <Feature key={f.title} icon={f.icon} title={f.title} desc={f.desc} />
          ))}
        </div>
      </Container>
    </section>
  );
}

/*************************
 * Demo Section
 *************************/
function Demo() {
  return (
    <section id="demo" className="relative scroll-mt-24 py-16 sm:py-20">
      <Container>
        <div className="grid items-center gap-10 lg:grid-cols-2">
          <div>
            <Typewriter as="h3" className="text-2xl font-semibold tracking-tight text-white sm:text-3xl" text="See it in action" speed={10} />
            <p className="mt-3 text-sm leading-relaxed text-white/70">
              Switch between full overlay and dot mode, align colors automatically, and collaborate through instant sharing. The overlay updates in real‑time as you move or edit it.
            </p>
            <ul className="mt-6 space-y-2 text-sm text-white/80">
              {["Pixel‑perfect snapping", "Tolerance‑based color matching", "Overlay above/behind tiles", "Multi‑overlay orchestration"].map((t) => (
                <li key={t} className="flex items-center gap-2"><CheckCircle2 className="h-4 w-4 text-emerald-400" /> {t}</li>
              ))}
            </ul>
          </div>
          <VideoMock />
        </div>
      </Container>
    </section>
  );
}

/*************************
 * Install Steps — Reproduced FR content
 *************************/
function Install() {
  return (
    <section id="install" className="relative scroll-mt-24 py-16 sm:py-20">
      <Container>
        <div className="mx-auto mb-10 max-w-2xl text-center">
          <Typewriter as="h3" className="text-2xl font-semibold tracking-tight text-white sm:text-3xl" text="Comment ça marche en trois étapes" speed={10} />
          <p className="mt-2 text-white/70">Du placement manuel à la précision parfaite — voici comment fonctionne Overlay Pro TT.</p>
        </div>
        <div className="grid gap-4 md:grid-cols-3">
          <motion.div initial={{ opacity: 0, y: 16 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.5 }} className="rounded-3xl border border-white/10 bg-white/5 p-6 text-center">
            <div className="mb-3 inline-flex">
              <span className="rounded-full p-[1px] bg-gradient-to-r from-fuchsia-500/25 via-violet-500/25 to-sky-500/25">
                <span className="block rounded-full border border-white/15 bg-white/5 px-3 py-1 text-xs text-white/80">Étape 1 sur 3</span>
              </span>
            </div>
            <h4 className="text-base font-semibold text-white">Installez Tampermonkey</h4>
            <p className="mt-2 text-sm text-white/70">Ajoutez l'extension Tampermonkey ou Greasemonkey à votre navigateur. Elle apparaît instantanément, prête à partir.</p>
            <a href="https://tampermonkey.net/" target="_blank" rel="noreferrer" className="mt-4 inline-flex"><Button className="border border-white/20 bg-white/0 text-white hover:bg-white/10">Obtenir Tampermonkey <ArrowRight className="ml-2 h-4 w-4" /></Button></a>
          </motion.div>

          <motion.div initial={{ opacity: 0, y: 16 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.5, delay: 0.05 }} className="rounded-3xl border border-white/10 bg-white/5 p-6 text-center">
            <div className="mb-3 inline-flex">
              <span className="rounded-full p-[1px] bg-gradient-to-r from-fuchsia-500/25 via-violet-500/25 to-sky-500/25">
                <span className="block rounded-full border border-white/15 bg-white/5 px-3 py-1 text-xs text-white/80">Étape 2 sur 3</span>
              </span>
            </div>
            <h4 className="text-base font-semibold text-white">Traitement instantané</h4>
            <p className="mt-2 text-sm text-white/70">Cliquez sur "Installer" et laissez Overlay Pro TT se configurer automatiquement. Prévisualisez immédiatement.</p>
            <a href="https://cdn.jsdelivr.net/gh/CreepsoOff/Wplace-Overlay-Pro@development/dist/overlay-pro-tt.user.js" target="_blank" rel="noreferrer" className="mt-4 inline-flex"><Button className="bg-white text-black hover:bg-white/90">Installer le Script <Download className="ml-2 h-4 w-4" /></Button></a>
          </motion.div>

          <motion.div initial={{ opacity: 0, y: 16 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.5, delay: 0.1 }} className="rounded-3xl border border-white/10 bg-white/5 p-6 text-center">
            <div className="mb-3 inline-flex">
              <span className="rounded-full p-[1px] bg-gradient-to-r from-fuchsia-500/25 via-violet-500/25 to-sky-500/25">
                <span className="block rounded-full border border-white/15 bg-white/5 px-3 py-1 text-xs text-white/80">Étape 3 sur 3</span>
              </span>
            </div>
            <h4 className="text-base font-semibold text-white">Une expérience, tous les outils</h4>
            <p className="mt-2 text-sm text-white/70">Overlay Pro TT active automatiquement TOUS ses outils sur wplace.live. Tout est déjà assemblé et prêt à utiliser.</p>
            <a href="https://wplace.live" target="_blank" rel="noreferrer" className="mt-4 inline-flex"><Button className="border border-white/20 bg-white/0 text-white hover:bg-white/10">Ouvrir wplace.live <ArrowRight className="ml-2 h-4 w-4" /></Button></a>
          </motion.div>
        </div>
      </Container>
    </section>
  );
}

/*************************
 * FAQ Section
 *************************/
function FAQSection() {
  const faqs = [
    { q: "Does it work with multiple overlays?", a: "Yes. You can load several overlays at once and manage them independently for complex artworks." },
    { q: "How does color matching work?", a: "We map each pixel to the closest color in the official wplace palette. You can tweak tolerance to prefer brighter/darker matches." },
    { q: "Is there a performance impact?", a: "The overlay engine is optimized with off‑main‑thread processing and batched updates to keep interactions silky smooth." },
    { q: "Which browsers are supported?", a: "All modern browsers with userscript support: Chrome, Firefox, Edge, Brave, and Opera (via Tampermonkey/Violentmonkey)." },
  ];
  const [openIndex, setOpenIndex] = useState<number | null>(null);
  const toggle = (i: number) => setOpenIndex((prev) => (prev === i ? null : i));
  return (
    <section id="faq" className="relative scroll-mt-24 py-16 sm:py-20">
      <Container>
        <div className="mx-auto mb-8 max-w-2xl text-center">
          <Typewriter as="h3" className="bg-gradient-to-tr from-fuchsia-400 via-violet-400 to-sky-400 bg-clip-text text-2xl font-semibold tracking-tight text-transparent sm:text-3xl" text="FAQ" speed={10} />
        </div>
        {/* One item per line */}
        <div className="grid gap-3">
          {faqs.map((f, i) => (
            <FAQItem key={f.q} q={f.q} a={f.a} open={openIndex === i} onToggle={() => toggle(i)} />
          ))}
        </div>
      </Container>
    </section>
  );
}

/*************************
 * Footer
 *************************/
function Footer() {
  return (
    <footer className="relative border-t border-white/10 py-10 text-sm text-white/60">
      <Container className="flex flex-col items-center justify-between gap-6 sm:flex-row">
        <div className="flex items-center gap-2">
          <div className="grid h-8 w-8 place-items-center rounded-xl bg-gradient-to-tr from-fuchsia-500 to-violet-500 text-white">
            <Layers className="h-4 w-4" />
          </div>
          <div>
            <p className="font-semibold text-white">Overlay Pro TT</p>
            <p className="text-xs">Smart overlay system for wplace.live</p>
          </div>
        </div>
        <div className="flex items-center gap-4">
          <a id="github" href="https://github.com/CreepsoOff" target="_blank" rel="noreferrer" className="hover:text-white"><Github className="h-5 w-5" /></a>
          <button onClick={() => scrollToSection('#install')} className="hover:text-white"><Download className="h-5 w-5" /></button>
        </div>
        <p className="text-xs">© {new Date().getFullYear()} Overlay Pro TT. All rights reserved.</p>
      </Container>
    </footer>
  );
}

/*************************
 * App (with safe smoke tests)
 *************************/
export default function App() {
  // Set page meta dynamically (works in Vite/SPA environments)
  useEffect(() => {
    document.title = "Overlay Pro TT — Pixel‑perfect overlays for wplace.live";
    const meta = document.querySelector('meta[name="description"]') as HTMLMetaElement | null;
    if (meta) meta.content = "Transform your wplace.live experience with intelligent overlays, color matching, and real‑time processing.";
    
  }, []);

  // Simple runtime smoke tests (dev-only, no auto-scroll)
  useEffect(() => {
    if ((import.meta as any)?.env?.DEV) {
      try {
        console.assert(typeof Typewriter === 'function', 'Typewriter component missing');
        console.assert(typeof scrollToSection === 'function', 'scrollToSection missing');
        console.assert(document.querySelector('header') !== null, 'Header should render');
        console.assert(typeof window.scrollTo === 'function', 'window.scrollTo must exist');
        // extra: ensure Typewriter outputs spans for each char
        const testSpans = document.querySelectorAll('#__test_zone [data-testid="tw-test"] span');
        if (testSpans.length > 0) {
          console.assert(testSpans.length >= 4, 'Typewriter should render at least 4 spans for "TEST"');
        }
        // new: ensure cursor span exists when cursor=true
        const cursor = document.querySelector('#__test_zone [data-testid="tw-cursor"]');
        console.assert(cursor !== null, 'Typewriter cursor should render when enabled');
        // DEV check: FAQ items count equals spec
const faqButtons = document.querySelectorAll('#faq button');
console.assert(faqButtons.length >= 4, 'FAQ should render at least 4 items');
console.info('[Overlay Pro TT] Dev smoke tests passed.');
      } catch (e) {
        console.warn('[Overlay Pro TT] Smoke tests failed:', e);
      }
    }
  }, []);

  const [loaded, setLoaded] = useState(false);
  useEffect(() => {
    const onReady = () => setTimeout(() => setLoaded(true), 650);
    if (document.readyState === 'complete' || document.readyState === 'interactive') onReady();
    else window.addEventListener('DOMContentLoaded', onReady);
    return () => window.removeEventListener('DOMContentLoaded', onReady);
  }, []);

  return (
    <div className="min-h-screen bg-[#0B0B10] text-white">
      <PageLoader done={loaded} />
      {/* hidden test zone for runtime checks */}
      <div id="__test_zone" className="hidden">
        <Typewriter as="span" text="TEST" speed={1} dataTestId="tw-test" />
        <Typewriter as="span" text="CURSOR" speed={1} cursor dataTestId="tw-test-cursor" />
      </div>
      <Header />
      <main>
        <Hero />
        <Features />
        <Demo />
        <Install />
        <FAQSection />
      </main>
      <Footer />
    </div>
  );
}

/*************************
 * Tailwind boilerplate (drop in your global.css)
 *************************/
// @tailwind base;
// @tailwind components;
// @tailwind utilities;
// html, body, #root { height: 100%; }
// body { @apply antialiased; }

/*************************
 * Notes
 *************************/
// 1) Lien Tampermonkey / Script / wplace.live intégrés dans la section Installation (FR).
// 2) Remplace VideoMock par ta démo réelle.
// 3) npm i framer-motion lucide-react
